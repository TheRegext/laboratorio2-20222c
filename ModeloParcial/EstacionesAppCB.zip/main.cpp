#include <iostream>
#include "ResumenDiarioArchivo.h"
using namespace std;

int main()
{
  ResumenDiarioArchivo resumen;
  int cantidad = resumen.getCantidad();
  ResumenDiario* resumenes = new ResumenDiario[cantidad];
  resumen.leerTodos(resumenes, cantidad);
  
  // mostrar
  for (int i = 0; i < cantidad; i++) {
    cout << resumenes[i].getIDEstacion() << endl;
  }

  
  
  
  
  return 0;
}
